package com.senhao.converter;

import android.content.*;
import android.graphics.*;
import android.graphics.pdf.*;
import android.media.*;
import android.os.ParcelFileDescriptor;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;
import android.app.*;
import androidx.core.content.FileProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import org.junit.*;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;
import java.io.*;
import java.nio.file.Files;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.zip.*;

@RunWith(AndroidJUnit4.class)
@androidx.media3.common.util.UnstableApi
public class ConversionDeviceTest {
    Context context;ArrayList<File> cleanup;
    @Before public void init(){context=InstrumentationRegistry.getInstrumentation().getTargetContext();cleanup=new ArrayList<>();}
    @After public void clean(){for(File f:cleanup)f.delete();}
    File fixtureImage(int color)throws IOException {File f=File.createTempFile("fixture",".png",context.getCacheDir());cleanup.add(f);Bitmap b=Bitmap.createBitmap(64,48,Bitmap.Config.ARGB_8888);b.eraseColor(color);try(FileOutputStream s=new FileOutputStream(f)){b.compress(Bitmap.CompressFormat.PNG,100,s);}b.recycle();return f;}
    File fixturePdf()throws IOException {File f=File.createTempFile("fixture",".pdf",context.getCacheDir());cleanup.add(f);try(Engines.PdfOutput owned=new Engines.PdfOutput()){PdfDocument doc=owned.doc;for(int i=0;i<2;i++){PdfDocument.Page p=doc.startPage(new PdfDocument.PageInfo.Builder(100,100,i+1).create());p.getCanvas().drawColor(Color.WHITE);Paint paint=new Paint();paint.setColor(Color.BLACK);p.getCanvas().drawRect(40,40,60,60,paint);doc.finishPage(p);}try(FileOutputStream s=new FileOutputStream(f)){doc.writeTo(s);}}return f;}
    File fixtureGif()throws IOException {File f=File.createTempFile("fixture",".gif",context.getCacheDir());cleanup.add(f);try(InputStream in=InstrumentationRegistry.getInstrumentation().getContext().getAssets().open("animated.gif");OutputStream out=new FileOutputStream(f)){byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)out.write(b,0,n);}return f;}
    Engines.Progress noProgress=(p,s)->{};
    @android.annotation.TargetApi(29)
    void screenshot(String name)throws IOException {
        try{Thread.sleep(700);}catch(InterruptedException e){Thread.currentThread().interrupt();throw new IOException(e);}
        Bitmap screenshot=InstrumentationRegistry.getInstrumentation().getUiAutomation().takeScreenshot();assertNotNull(screenshot);
        ContentValues values=new ContentValues();values.put(MediaStore.MediaColumns.DISPLAY_NAME,name);values.put(MediaStore.MediaColumns.MIME_TYPE,"image/png");values.put(MediaStore.MediaColumns.RELATIVE_PATH,"Download");Uri uri=context.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);assertNotNull(uri);
        try(OutputStream out=context.getContentResolver().openOutputStream(uri)){assertNotNull(out);screenshot.compress(Bitmap.CompressFormat.PNG,100,out);}screenshot.recycle();
    }
    TextView find(View root,String value){if(root instanceof TextView&&value.equals(((TextView)root).getText().toString()))return (TextView)root;if(root instanceof android.view.ViewGroup){android.view.ViewGroup group=(android.view.ViewGroup)root;for(int i=0;i<group.getChildCount();i++){TextView match=find(group.getChildAt(i),value);if(match!=null)return match;}}return null;}
    void waitText(MainActivity activity,String value)throws Exception{long end=System.currentTimeMillis()+10000;AtomicBoolean found=new AtomicBoolean();while(System.currentTimeMillis()<end){InstrumentationRegistry.getInstrumentation().runOnMainSync(()->found.set(find(activity.getWindow().getDecorView(),value)!=null));if(found.get())return;Thread.sleep(50);}fail("Missing UI state: "+value);}
    @Test public void imageFormatsAndResizePreserveSource()throws Exception {
        File input=fixtureImage(Color.RED);byte[] before=Files.readAllBytes(input.toPath());
        for(String format:new String[]{"PNG","JPG","WEBP","BMP"}){Engines.Config c=new Engines.Config();c.format=format;c.width=32;File out=Engines.images(context,Collections.singletonList(input),c,new AtomicBoolean(),noProgress);cleanup.add(out);Bitmap b=Engines.loadImage(out);assertEquals(32,b.getWidth());assertEquals(24,b.getHeight());assertTrue(Color.red(b.getPixel(10,10))>200);b.recycle();}
        assertArrayEquals(before,Files.readAllBytes(input.toPath()));
    }
    @Test public void imagesToPdfAndPagesZip()throws Exception {
        Engines.Config c=new Engines.Config();c.operation="图片 → PDF";File out=Engines.images(context,Arrays.asList(fixtureImage(Color.RED),fixtureImage(Color.BLUE)),c,new AtomicBoolean(),noProgress);cleanup.add(out);
        try(ParcelFileDescriptor p=ParcelFileDescriptor.open(out,ParcelFileDescriptor.MODE_READ_ONLY);PdfRenderer r=new PdfRenderer(p)){assertEquals(2,r.getPageCount());}
        c.operation="PDF → 图片 ZIP";c.dpi=72;c.format="PNG";File zip=Engines.pdf(context,out,c,new AtomicBoolean(),noProgress);cleanup.add(zip);
        try(ZipFile z=new ZipFile(zip)){assertEquals(2,z.size());assertNotNull(z.getEntry("page_001.png"));assertNotNull(z.getEntry("page_002.png"));}
    }
    @Test public void pdfRepairOnlySelectedPageAndOriginalUnchanged()throws Exception {
        File input=fixturePdf();byte[] before=Files.readAllBytes(input.toPath());Engines.Config c=new Engines.Config();c.operation="PDF 水印修补";c.dpi=72;c.page=2;c.boxes=Collections.singletonList(new RectF(.3f,.3f,.7f,.7f));
        File output=Engines.pdf(context,input,c,new AtomicBoolean(),noProgress);cleanup.add(output);Bitmap first=Engines.pdfPage(output,0,72),second=Engines.pdfPage(output,1,72);assertEquals(Color.BLACK,first.getPixel(50,50));assertEquals(Color.WHITE,second.getPixel(50,50));first.recycle();second.recycle();assertArrayEquals(before,Files.readAllBytes(input.toPath()));
    }
    @Test public void cancellationDoesNotReturnResult()throws Exception {AtomicBoolean cancelled=new AtomicBoolean(true);try{Engines.images(context,Collections.singletonList(fixtureImage(Color.RED)),new Engines.Config(),cancelled,noProgress);fail("Expected cancellation");}catch(IOException expected){assertTrue(expected.getMessage().contains("取消"));}}
    @Test public void gifProducesActualAnimatedMp4()throws Exception {
        File out=GifEngine.convert(context,fixtureGif(),new Engines.Config(),new AtomicBoolean(),noProgress);cleanup.add(out);
        try(Engines.VideoReader owned=new Engines.VideoReader()){MediaMetadataRetriever r=owned.reader;r.setDataSource(out.getPath());assertTrue(Long.parseLong(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION))>=700);Bitmap first=r.getFrameAtTime(100000,MediaMetadataRetriever.OPTION_CLOSEST),last=r.getFrameAtTime(700000,MediaMetadataRetriever.OPTION_CLOSEST);assertNotNull(first);assertNotNull(last);assertNotEquals(first.getPixel(10,10),last.getPixel(10,10));first.recycle();last.recycle();}
    }
    @Test public void videoResizeExportsMp4()throws Exception {
        File input=GifEngine.convert(context,fixtureGif(),new Engines.Config(),new AtomicBoolean(),noProgress);cleanup.add(input);CountDownLatch done=new CountDownLatch(1);AtomicReference<File> result=new AtomicReference<>();AtomicReference<Exception> error=new AtomicReference<>();Engines.Config c=new Engines.Config();c.operation="视频 → MP4";c.height=48;
        InstrumentationRegistry.getInstrumentation().runOnMainSync(()->new VideoEngine().start(context,input,c,new AtomicBoolean(),noProgress,new VideoEngine.Completion(){public void success(File f,String d){result.set(f);done.countDown();}public void failure(Exception e){error.set(e);done.countDown();}}));
        assertTrue("Video export timeout",done.await(120,TimeUnit.SECONDS));if(error.get()!=null)throw error.get();assertNotNull(result.get());cleanup.add(result.get());try(Engines.VideoReader owned=new Engines.VideoReader()){MediaMetadataRetriever reader=owned.reader;reader.setDataSource(result.get().getPath());assertEquals("48",reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));}
    }
    @Test public void candidatesRequireSelectionAndHomeRenders()throws Exception {
        InstrumentationRegistry.getInstrumentation().runOnMainSync(()->{RegionView region=new RegionView(context);region.candidates(Collections.singletonList(new RectF(.1f,.1f,.3f,.3f)));assertTrue(region.selected().isEmpty());});
        Intent intent=new Intent(context,MainActivity.class);intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);MainActivity activity=(MainActivity)InstrumentationRegistry.getInstrumentation().startActivitySync(intent);InstrumentationRegistry.getInstrumentation().waitForIdleSync();
        screenshot("android-home.png");InstrumentationRegistry.getInstrumentation().runOnMainSync(activity::finish);
    }
    @Test public void uiConversionAndSaveShareIntents()throws Exception {
        Instrumentation instrumentation=InstrumentationRegistry.getInstrumentation();Intent launch=new Intent(context,MainActivity.class);launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);MainActivity activity=(MainActivity)instrumentation.startActivitySync(launch);instrumentation.waitForIdleSync();File input=fixtureImage(Color.GREEN);
        instrumentation.runOnMainSync(()->activity.onActivityResult(10,Activity.RESULT_OK,new Intent().setData(Uri.fromFile(input))));waitText(activity,"文件已就绪");
        instrumentation.runOnMainSync(()->{TextView b=find(activity.getWindow().getDecorView(),"开始转换");assertNotNull(b);b.performClick();});waitText(activity,"转换成功");
        File[] results=new File(context.getFilesDir(),"results").listFiles();assertNotNull(results);assertTrue(results.length>0);File result=Arrays.stream(results).max(Comparator.comparingLong(File::lastModified)).get();cleanup.add(result);Uri shared=FileProvider.getUriForFile(context,context.getPackageName()+".files",result);try(InputStream stream=context.getContentResolver().openInputStream(shared)){assertNotNull(stream);assertEquals(255,stream.read());assertEquals(216,stream.read());}
        IntentFilter saveFilter=new IntentFilter(Intent.ACTION_CREATE_DOCUMENT);saveFilter.addDataType("*/*");saveFilter.addCategory(Intent.CATEGORY_OPENABLE);Instrumentation.ActivityMonitor save=instrumentation.addMonitor(saveFilter,new Instrumentation.ActivityResult(Activity.RESULT_CANCELED,null),true);instrumentation.runOnMainSync(()->find(activity.getWindow().getDecorView(),"保存到手机文件夹").performClick());instrumentation.waitForIdleSync();assertEquals(1,save.getHits());instrumentation.removeMonitor(save);
        File saved=File.createTempFile("saved",".jpg",context.getCacheDir());cleanup.add(saved);instrumentation.runOnMainSync(()->activity.onActivityResult(11,Activity.RESULT_OK,new Intent().setData(Uri.fromFile(saved))));waitText(activity,"已保存到你选择的位置");assertArrayEquals(Files.readAllBytes(result.toPath()),Files.readAllBytes(saved.toPath()));
        Instrumentation.ActivityMonitor share=instrumentation.addMonitor(new IntentFilter(Intent.ACTION_CHOOSER),new Instrumentation.ActivityResult(Activity.RESULT_CANCELED,null),true);instrumentation.runOnMainSync(()->find(activity.getWindow().getDecorView(),"分享结果").performClick());instrumentation.waitForIdleSync();assertEquals(1,share.getHits());instrumentation.removeMonitor(share);
        instrumentation.runOnMainSync(()->{android.view.ViewGroup decor=(android.view.ViewGroup)activity.getWindow().getDecorView();ScrollView scroll=findScroll(decor);assertNotNull(scroll);scroll.fullScroll(View.FOCUS_DOWN);});instrumentation.waitForIdleSync();screenshot("android-result.png");instrumentation.runOnMainSync(activity::finish);
    }
    ScrollView findScroll(View root){if(root instanceof ScrollView)return (ScrollView)root;if(root instanceof android.view.ViewGroup){android.view.ViewGroup group=(android.view.ViewGroup)root;for(int i=0;i<group.getChildCount();i++){ScrollView found=findScroll(group.getChildAt(i));if(found!=null)return found;}}return null;}
}
