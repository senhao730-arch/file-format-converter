package com.senhao.converter;
import org.junit.Test;
import static org.junit.Assert.*;
import java.util.Arrays;
public class PixelOpsTest {
    @Test public void fitKeepsAspect(){assertArrayEquals(new int[]{1920,1080},PixelOps.fit(3840,2160,1920,0));assertArrayEquals(new int[]{1080,608},PixelOps.fit(3840,2160,1080,1080));}
    @Test public void originalSize(){assertArrayEquals(new int[]{513,271},PixelOps.fit(513,271,0,0));}
    @Test(expected=IllegalArgumentException.class)public void hugeImageRejected(){PixelOps.fit(1000,1000,10000,10000);}
    @Test public void repairFlatBackground(){int[] p=new int[100];Arrays.fill(p,0xffeeeeee);p[44]=0xff000000;PixelOps.repair(p,10,10,3,3,7,7);assertEquals(0xffeeeeee,p[44]);}
    @Test public void repairPreservesOutside(){int[] p=new int[100];for(int i=0;i<100;i++)p[i]=0xff000000|i;int[] old=p.clone();PixelOps.repair(p,10,10,3,3,7,7);for(int y=0;y<10;y++)for(int x=0;x<10;x++)if(x<3||x>=7||y<3||y>=7)assertEquals(old[y*10+x],p[y*10+x]);}
    @Test public void detailPreservesAlphaAndInput(){int[] p=new int[25];Arrays.fill(p,0x80aaaaaa);int[] old=p.clone(),q=PixelOps.detail(p,5,5,2,1);assertArrayEquals(old,p);assertArrayEquals(p,q);}
    @Test public void extremeDetailClamped(){int[] p=new int[9];Arrays.fill(p,0xff000000);p[4]=0xffffffff;assertEquals(0xffffffff,PixelOps.detail(p,3,3,2,0)[4]);}
    @Test(expected=IllegalArgumentException.class)public void badRectRejected(){PixelOps.repair(new int[4],2,2,0,0,2,2);}
}
