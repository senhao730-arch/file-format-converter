package com.senhao.converter;

import android.content.Context;
import android.graphics.*;
import android.media.*;
import java.io.*;
import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicBoolean;

public final class GifEngine {
    private static final int FPS=15;
    public static File convert(Context context,File source,Engines.Config config,AtomicBoolean cancel,Engines.Progress progress)throws IOException {
        if(source.length()>100_000_000)throw new IOException("GIF 超过 100 MB，请先缩小文件");
        Movie movie=Movie.decodeFile(source.getPath());if(movie==null)throw new IOException("无法解码 GIF");
        int duration=movie.duration();if(duration<=0)duration=1000;if(duration>120000)throw new IOException("首版支持最长 2 分钟 GIF");
        int[] fit=PixelOps.fit(movie.width(),movie.height(),config.width,config.height);
        double scale=Math.min(1,1280d/Math.max(fit[0],fit[1]));int w=Math.max(2,((int)(fit[0]*scale)/2)*2),h=Math.max(2,((int)(fit[1]*scale)/2)*2);
        MediaFormat format=MediaFormat.createVideoFormat("video/avc",w,h);format.setInteger(MediaFormat.KEY_COLOR_FORMAT,MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible);format.setInteger(MediaFormat.KEY_BIT_RATE,config.quality<=40?1_500_000:config.quality<=70?4_000_000:8_000_000);format.setInteger(MediaFormat.KEY_FRAME_RATE,FPS);format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL,1);
        MediaCodec codec=null;MediaMuxer muxer=null;boolean started=false,codecStarted=false;File out=Engines.result(context,"mp4");Bitmap bitmap=null;
        try{
            codec=MediaCodec.createEncoderByType("video/avc");codec.configure(format,null,null,MediaCodec.CONFIGURE_FLAG_ENCODE);codec.start();codecStarted=true;
            muxer=new MediaMuxer(out.getPath(),MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);bitmap=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);Canvas canvas=new Canvas(bitmap);
            int frameCount=Math.max(1,(duration*FPS+999)/1000),nextFrame=0,track=-1;boolean eosIn=false,eosOut=false;MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();int[] pixels=new int[w*h];long lastOutput=System.currentTimeMillis();
            while(!eosOut){Engines.cancelled(cancel);if(System.currentTimeMillis()-lastOutput>30000)throw new IOException("GIF 编码超时，此手机可能不支持该编码方式");
                if(!eosIn){int index=codec.dequeueInputBuffer(10000);if(index>=0){
                    if(nextFrame>=frameCount){codec.queueInputBuffer(index,0,0,nextFrame*1000000L/FPS,MediaCodec.BUFFER_FLAG_END_OF_STREAM);eosIn=true;}
                    else {
                        movie.setTime(Math.min(duration-1,nextFrame*1000/FPS));canvas.drawColor(Color.WHITE);canvas.save();canvas.scale((float)w/movie.width(),(float)h/movie.height());movie.draw(canvas,0,0);canvas.restore();bitmap.getPixels(pixels,0,w,0,0,w,h);
                        Image image=codec.getInputImage(index);if(image==null)throw new IOException("此手机编码器不提供 YUV 输入平面，GIF 转 MP4 暂不可用");
                        writeYuv(image,pixels,w,h);image.close();codec.queueInputBuffer(index,0,w*h*3/2,nextFrame*1000000L/FPS,0);progress.update(++nextFrame*95/frameCount,"编码 GIF 第 "+nextFrame+" / "+frameCount+" 帧");
                    }
                }}
                int index=codec.dequeueOutputBuffer(info,10000);
                if(index==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED){if(started)throw new IOException("编码格式异常");track=muxer.addTrack(codec.getOutputFormat());muxer.start();started=true;lastOutput=System.currentTimeMillis();}
                else if(index>=0){ByteBuffer data=codec.getOutputBuffer(index);if((info.flags&MediaCodec.BUFFER_FLAG_CODEC_CONFIG)!=0)info.size=0;
                    if(info.size>0){if(!started||data==null)throw new IOException("未取得编码输出");data.position(info.offset);data.limit(info.offset+info.size);muxer.writeSampleData(track,data,info);}eosOut=(info.flags&MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0;codec.releaseOutputBuffer(index,false);lastOutput=System.currentTimeMillis();}
            }
            if(!started)throw new IOException("GIF 编码未产生视频");muxer.stop();started=false;Engines.cancelled(cancel);return out;
        }catch(IOException|RuntimeException|OutOfMemoryError e){out.delete();throw e;}
        finally {if(bitmap!=null)bitmap.recycle();if(codec!=null){try{if(codecStarted)codec.stop();}catch(Exception ignored){}codec.release();}if(muxer!=null){try{if(started)muxer.stop();}catch(Exception ignored){}muxer.release();}if(cancel.get())out.delete();}
    }
    static void writeYuv(Image image,int[] pixels,int w,int h)throws IOException {
        Image.Plane[] planes=image.getPlanes();if(planes.length!=3)throw new IOException("无效 YUV 编码平面");
        for(int y=0;y<h;y++)for(int x=0;x<w;x++){
            int c=pixels[y*w+x],r=Color.red(c),g=Color.green(c),b=Color.blue(c);
            put(planes[0],x,y,PixelOps.clamp(((66*r+129*g+25*b+128)>>8)+16));
            if((x&1)==0&&(y&1)==0){int ar=0,ag=0,ab=0;for(int dy=0;dy<2;dy++)for(int dx=0;dx<2;dx++){int v=pixels[(y+dy)*w+x+dx];ar+=Color.red(v);ag+=Color.green(v);ab+=Color.blue(v);}ar/=4;ag/=4;ab/=4;
                put(planes[1],x/2,y/2,PixelOps.clamp(((-38*ar-74*ag+112*ab+128)>>8)+128));put(planes[2],x/2,y/2,PixelOps.clamp(((112*ar-94*ag-18*ab+128)>>8)+128));}
        }
    }
    private static void put(Image.Plane plane,int x,int y,int value){plane.getBuffer().put(y*plane.getRowStride()+x*plane.getPixelStride(),(byte)value);}
}
