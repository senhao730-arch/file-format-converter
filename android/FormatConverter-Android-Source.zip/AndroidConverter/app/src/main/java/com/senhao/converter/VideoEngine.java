package com.senhao.converter;

import android.content.Context;
import android.net.Uri;
import android.graphics.RectF;
import android.os.*;
import androidx.media3.common.*;
import androidx.media3.effect.*;
import androidx.media3.transformer.*;
import java.io.File;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

@androidx.media3.common.util.UnstableApi
public final class VideoEngine {
    public interface Completion { void success(File file,String details); void failure(Exception error); }
    private Transformer transformer; private Runnable polling; private final Handler handler=new Handler(Looper.getMainLooper());
    private File output; private boolean finished;
    public void start(Context context,File source,Engines.Config config,AtomicBoolean cancel,Engines.Progress progress,Completion completion){
        output=Engines.result(context,"mp4");ArrayList<Effect> effects=new ArrayList<>();
        if(config.operation.equals("视频裁剪 → MP4")){
            if(config.boxes.isEmpty()){completion.failure(new IllegalArgumentException("请在预览中框选要保留的区域"));return;}
            RectF r=config.boxes.get(config.boxes.size()-1);effects.add(new Crop(2*r.left-1,2*r.right-1,1-2*r.bottom,1-2*r.top));
        }
        // An explicit non-no-op GlEffect keeps requested bitrate exports on the encode path.
        effects.add(new GlEffect(){
            @Override public GlShaderProgram toGlShaderProgram(Context c,boolean hdr)throws VideoFrameProcessingException {return new Contrast(config.sharpen*.25f).toGlShaderProgram(c,hdr);}
            @Override public boolean isNoOp(int w,int h){return false;}
        });
        if(config.height>0)effects.add(Presentation.createForHeight(config.height));
        else if(config.width>0)effects.add(Presentation.createForWidthAndHeight(config.width,config.width,Presentation.LAYOUT_SCALE_TO_FIT));
        EditedMediaItem edited=new EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(source))).setRemoveAudio(config.mute).setEffects(new Effects(Collections.emptyList(),effects)).build();
        int bitrate=config.quality<=40?1_500_000:config.quality<=70?4_000_000:8_000_000;
        DefaultEncoderFactory encoder=new DefaultEncoderFactory.Builder(context).setRequestedVideoEncoderSettings(new VideoEncoderSettings.Builder().setBitrate(bitrate).build()).build();
        finished=false;
        transformer=new Transformer.Builder(context).setVideoMimeType(MimeTypes.VIDEO_H264).setAudioMimeType(MimeTypes.AUDIO_AAC).setEncoderFactory(encoder).addListener(new Transformer.Listener(){
            @Override public void onCompleted(Composition composition,ExportResult result){if(finished)return;finished=true;handler.removeCallbacks(polling);if(cancel.get()){output.delete();completion.failure(new IllegalStateException("已取消"));}else completion.success(output,"MP4 / H.264 · "+(result.averageVideoBitrate>0?Math.round(result.averageVideoBitrate/1000f)+" kbps":"已完成"));}
            @Override public void onError(Composition composition,ExportResult result,ExportException exception){if(finished)return;finished=true;handler.removeCallbacks(polling);output.delete();completion.failure(new IllegalStateException("此手机无法处理该视频编码。请尝试较低分辨率或其他源文件。\n"+exception.getErrorCodeName(),exception));}
        }).build();
        polling=new Runnable(){public void run(){if(finished)return;if(cancel.get()){cancel();completion.failure(new IllegalStateException("已取消，原文件保留"));return;}ProgressHolder holder=new ProgressHolder();if(transformer.getProgress(holder)==Transformer.PROGRESS_STATE_AVAILABLE)progress.update(holder.progress,"正在编码视频 "+holder.progress+"%");handler.postDelayed(this,400);}};
        try{transformer.start(edited,output.getPath());handler.post(polling);}catch(Exception e){finished=true;output.delete();completion.failure(e);}
    }
    public void cancel(){finished=true;if(polling!=null)handler.removeCallbacks(polling);if(transformer!=null)transformer.cancel();if(output!=null)output.delete();}
}
