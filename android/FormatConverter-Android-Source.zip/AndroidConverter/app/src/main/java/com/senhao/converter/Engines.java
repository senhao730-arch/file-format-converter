package com.senhao.converter;

import android.content.Context;
import android.graphics.*;
import android.graphics.pdf.*;
import android.os.ParcelFileDescriptor;
import android.media.MediaMetadataRetriever;
import androidx.exifinterface.media.ExifInterface;
import java.io.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.zip.*;

public final class Engines {
    static final class PdfOutput implements AutoCloseable { final PdfDocument doc=new PdfDocument();public void close(){doc.close();} }
    static final class VideoReader implements AutoCloseable { final MediaMetadataRetriever reader=new MediaMetadataRetriever();public void close()throws IOException{reader.release();} }
    public interface Progress { void update(int percent,String message); }
    public static final class Config {
        public String operation="图片转换",format="JPG";
        public int width=0,height=0,quality=90,dpi=150,page=1;
        public float sharpen=0,denoise=0;
        public boolean mute=false;
        public List<RectF> boxes=Collections.emptyList();
    }
    static void cancelled(AtomicBoolean c)throws IOException {if(c.get()||Thread.currentThread().isInterrupted())throw new IOException("已取消，原文件保留");}
    static void bounds(int width,int height)throws IOException {if(width<1||height<1||width>8192||height>8192||(long)width*height>12_000_000)throw new IOException("尺寸过大，请控制在 1200 万像素、单边 8192 以内");}
    public static Bitmap loadImage(File file)throws IOException {
        BitmapFactory.Options o=new BitmapFactory.Options();o.inJustDecodeBounds=true;BitmapFactory.decodeFile(file.getPath(),o);
        if(o.outWidth<=0||o.outHeight<=0)throw new IOException("无法读取图片，此手机可能不支持该格式");
        int sample=1;while(o.outWidth/sample>4096||o.outHeight/sample>4096||(long)(o.outWidth/sample)*(o.outHeight/sample)>8_000_000)sample*=2;
        o.inJustDecodeBounds=false;o.inSampleSize=sample;o.inPreferredConfig=Bitmap.Config.ARGB_8888;
        Bitmap bitmap=BitmapFactory.decodeFile(file.getPath(),o);if(bitmap==null)throw new IOException("无法解码图片");
        Matrix m=new Matrix();
        try {int orientation=new ExifInterface(file).getAttributeInt(ExifInterface.TAG_ORIENTATION,ExifInterface.ORIENTATION_NORMAL);
            switch(orientation){case 2:m.setScale(-1,1);break;case 3:m.setRotate(180);break;case 4:m.setRotate(180);m.postScale(-1,1);break;case 5:m.setRotate(90);m.postScale(-1,1);break;case 6:m.setRotate(90);break;case 7:m.setRotate(-90);m.postScale(-1,1);break;case 8:m.setRotate(-90);break;}
        }catch(IOException ignored){}
        if(!m.isIdentity()){Bitmap rotated=Bitmap.createBitmap(bitmap,0,0,bitmap.getWidth(),bitmap.getHeight(),m,true);if(rotated!=bitmap)bitmap.recycle();bitmap=rotated;}
        return bitmap;
    }
    public static Bitmap adjust(Bitmap input,Config config,AtomicBoolean cancel)throws IOException {
        cancelled(cancel);int[] size=PixelOps.fit(input.getWidth(),input.getHeight(),config.width,config.height);bounds(size[0],size[1]);
        Bitmap resized=Bitmap.createScaledBitmap(input,size[0],size[1],true);
        Bitmap out=resized.copy(Bitmap.Config.ARGB_8888,true);if(resized!=input)resized.recycle();
        if(!config.boxes.isEmpty()||config.sharpen>0||config.denoise>0){
            int w=out.getWidth(),h=out.getHeight();int[] pixels=new int[w*h];out.getPixels(pixels,0,w,0,0,w,h);
            for(RectF r:config.boxes){cancelled(cancel);PixelOps.repair(pixels,w,h,(int)(r.left*w),(int)(r.top*h),(int)Math.ceil(r.right*w),(int)Math.ceil(r.bottom*h));}
            if(config.sharpen>0||config.denoise>0)pixels=PixelOps.detail(pixels,w,h,config.sharpen,config.denoise);
            cancelled(cancel);out.setPixels(pixels,0,w,0,0,w,h);
        }return out;
    }
    /** Heuristic corner candidates only: no OCR, and callers must require manual selection. */
    public static List<RectF> detect(Bitmap image) {
        Bitmap small=Bitmap.createScaledBitmap(image,Math.min(512,image.getWidth()),Math.max(1,Math.round(image.getHeight()*Math.min(512f/image.getWidth(),1f))),true);
        int w=small.getWidth(),h=small.getHeight();ArrayList<RectF> found=new ArrayList<>();
        RectF[] corners={new RectF(.03f,.03f,.35f,.19f),new RectF(.65f,.03f,.97f,.19f),new RectF(.03f,.81f,.35f,.97f),new RectF(.65f,.81f,.97f,.97f)};
        for(RectF r:corners){int l=Math.max(1,(int)(r.left*w)),t=Math.max(1,(int)(r.top*h)),rr=Math.min(w-1,(int)(r.right*w)),b=Math.min(h-1,(int)(r.bottom*h));int edge=0,total=0;
            for(int y=t;y<b;y++)for(int x=l;x<rr;x++){int c=small.getPixel(x,y),d=small.getPixel(x+1,y);int bright=(Color.red(c)+Color.green(c)+Color.blue(c))/3;int contrast=Math.abs(Color.red(c)-Color.red(d))+Math.abs(Color.green(c)-Color.green(d))+Math.abs(Color.blue(c)-Color.blue(d));if((bright>170||bright<70)&&contrast>95)edge++;total++;}
            float fraction=total==0?0:edge/(float)total;if(fraction>.018&&fraction<.35)found.add(r);
        }if(small!=image)small.recycle();return found;
    }
    public static Bitmap pdfPage(File source,int index,int dpi)throws IOException {
        try(ParcelFileDescriptor pfd=ParcelFileDescriptor.open(source,ParcelFileDescriptor.MODE_READ_ONLY);PdfRenderer renderer=new PdfRenderer(pfd)){
            if(index<0||index>=renderer.getPageCount())throw new IOException("页码超出范围，共 "+renderer.getPageCount()+" 页");
            try(PdfRenderer.Page page=renderer.openPage(index)){return render(page,dpi);}
        }
    }
    static Bitmap render(PdfRenderer.Page page,int dpi)throws IOException {
        int w=Math.max(1,Math.round(page.getWidth()*dpi/72f)),h=Math.max(1,Math.round(page.getHeight()*dpi/72f));bounds(w,h);
        Bitmap bitmap=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);bitmap.eraseColor(Color.WHITE);page.render(bitmap,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);return bitmap;
    }
    public static File result(Context context,String extension){File dir=new File(context.getFilesDir(),"jobs");dir.mkdirs();return new File(dir,"转换结果_"+System.currentTimeMillis()+"_"+UUID.randomUUID().toString().substring(0,6)+"."+extension);}
    public static String extension(String format){return format.equals("JPG")?"jpg":format.toLowerCase(Locale.ROOT);}
    public static void writeBitmap(Bitmap input,String format,int quality,OutputStream output)throws IOException {
        if(format.equals("BMP")){writeBmp(input,output);return;}
        Bitmap bitmap=input;
        if(format.equals("JPG")){bitmap=Bitmap.createBitmap(input.getWidth(),input.getHeight(),Bitmap.Config.ARGB_8888);Canvas c=new Canvas(bitmap);c.drawColor(Color.WHITE);c.drawBitmap(input,0,0,null);}
        Bitmap.CompressFormat encoding=format.equals("PNG")?Bitmap.CompressFormat.PNG:format.equals("WEBP")?Bitmap.CompressFormat.WEBP:Bitmap.CompressFormat.JPEG;
        try {if(!bitmap.compress(encoding,quality,output))throw new IOException("图片编码失败");}finally{if(bitmap!=input)bitmap.recycle();}
    }
    private static void le(OutputStream o,long n,int bytes)throws IOException{for(int i=0;i<bytes;i++)o.write((int)(n>>>(8*i))&255);}
    static void writeBmp(Bitmap b,OutputStream o)throws IOException {
        int w=b.getWidth(),h=b.getHeight(),row=(w*3+3)&~3;le(o,0x4d42,2);le(o,54L+row*(long)h,4);le(o,0,4);le(o,54,4);le(o,40,4);le(o,w,4);le(o,h,4);le(o,1,2);le(o,24,2);le(o,0,4);le(o,row*(long)h,4);le(o,2835,4);le(o,2835,4);le(o,0,4);le(o,0,4);
        int[] pixels=new int[w];byte[] bytes=new byte[row];
        for(int y=h-1;y>=0;y--){b.getPixels(pixels,0,w,0,y,w,1);for(int x=0;x<w;x++){int c=pixels[x],a=Color.alpha(c);bytes[x*3]=(byte)((Color.blue(c)*a+255*(255-a))/255);bytes[x*3+1]=(byte)((Color.green(c)*a+255*(255-a))/255);bytes[x*3+2]=(byte)((Color.red(c)*a+255*(255-a))/255);}o.write(bytes);}
    }
    public static File images(Context context,List<File> inputs,Config config,AtomicBoolean cancel,Progress progress)throws IOException {
        boolean toPdf=config.operation.equals("图片 → PDF");File out=result(context,toPdf?"pdf":extension(config.format));
        try{
            if(!toPdf){Bitmap input=loadImage(inputs.get(0));Bitmap adjusted=null;
                try{adjusted=adjust(input,config,cancel);try(OutputStream stream=new FileOutputStream(out)){writeBitmap(adjusted,config.format,config.quality,stream);}}finally{input.recycle();if(adjusted!=null)adjusted.recycle();}
            }else try(PdfOutput owned=new PdfOutput()){
                PdfDocument doc=owned.doc;
                int index=0;for(File file:inputs){cancelled(cancel);Bitmap bitmap=loadImage(file),adjusted=null;
                    try{adjusted=adjust(bitmap,config,cancel);float scale=Math.min(1,2048f/Math.max(adjusted.getWidth(),adjusted.getHeight()));int w=Math.max(1,Math.round(adjusted.getWidth()*scale)),h=Math.max(1,Math.round(adjusted.getHeight()*scale));
                        PdfDocument.Page p=doc.startPage(new PdfDocument.PageInfo.Builder(w,h,index+1).create());p.getCanvas().drawColor(Color.WHITE);p.getCanvas().drawBitmap(adjusted,null,new Rect(0,0,w,h),new Paint(Paint.FILTER_BITMAP_FLAG));doc.finishPage(p);
                    }finally{bitmap.recycle();if(adjusted!=null)adjusted.recycle();}progress.update(++index*90/inputs.size(),"合成第 "+index+" / "+inputs.size()+" 页");
                }cancelled(cancel);try(OutputStream stream=new FileOutputStream(out)){doc.writeTo(stream);}
            }
            cancelled(cancel);return out;
        }catch(IOException|RuntimeException|OutOfMemoryError e){out.delete();throw e;}
    }
    public static File pdf(Context context,File input,Config config,AtomicBoolean cancel,Progress progress)throws IOException {
        boolean images=config.operation.equals("PDF → 图片 ZIP");File out=result(context,images?"zip":"pdf");
        try(ParcelFileDescriptor pfd=ParcelFileDescriptor.open(input,ParcelFileDescriptor.MODE_READ_ONLY);PdfRenderer renderer=new PdfRenderer(pfd)){
            int count=renderer.getPageCount();if(count<1||count>200)throw new IOException("仅处理 1–200 页的 PDF，请先拆分大文档");
            if(config.operation.equals("PDF 水印修补")&&(config.page<1||config.page>count))throw new IOException("页码超出范围");
            try(OutputStream stream=new FileOutputStream(out);PdfOutput owned=images?null:new PdfOutput();ZipOutputStream zip=images?new ZipOutputStream(stream):null){
                PdfDocument document=images?null:owned.doc;
                for(int index=0;index<count;index++){cancelled(cancel);
                    try(PdfRenderer.Page page=renderer.openPage(index)){
                        Bitmap bitmap=render(page,config.dpi),adjusted=null;
                        try{
                            Config pageConfig=new Config();pageConfig.quality=config.quality;pageConfig.sharpen=config.sharpen;pageConfig.denoise=config.denoise;
                            if(config.operation.equals("PDF 水印修补")&&index==config.page-1)pageConfig.boxes=config.boxes;
                            adjusted=adjust(bitmap,pageConfig,cancel);
                            if(images){zip.putNextEntry(new ZipEntry(String.format(Locale.ROOT,"page_%03d.%s",index+1,extension(config.format))));writeBitmap(adjusted,config.format,config.quality,zip);zip.closeEntry();}
                            else {Bitmap rendered=adjusted;if(config.operation.equals("PDF 压缩")){ByteArrayOutputStream encoded=new ByteArrayOutputStream();writeBitmap(adjusted,"JPG",config.quality,encoded);byte[] data=encoded.toByteArray();rendered=BitmapFactory.decodeByteArray(data,0,data.length);if(rendered==null)throw new IOException("页面压缩失败");}
                                PdfDocument.Page p=document.startPage(new PdfDocument.PageInfo.Builder(page.getWidth(),page.getHeight(),index+1).create());p.getCanvas().drawColor(Color.WHITE);p.getCanvas().drawBitmap(rendered,null,new Rect(0,0,page.getWidth(),page.getHeight()),new Paint(Paint.FILTER_BITMAP_FLAG));document.finishPage(p);if(rendered!=adjusted)rendered.recycle();}
                        }finally{bitmap.recycle();if(adjusted!=null)adjusted.recycle();}
                    }progress.update((index+1)*90/count,"处理第 "+(index+1)+" / "+count+" 页");
                }cancelled(cancel);if(images)zip.finish();else document.writeTo(stream);
            }cancelled(cancel);return out;
        }catch(IOException|RuntimeException|OutOfMemoryError e){out.delete();throw e;}
    }
}
