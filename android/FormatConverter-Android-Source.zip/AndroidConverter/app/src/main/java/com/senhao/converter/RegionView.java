package com.senhao.converter;

import android.content.Context;
import android.graphics.*;
import android.view.*;
import java.util.*;

public final class RegionView extends View {
    private Bitmap image;
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
    private RectF bounds=new RectF();
    private final ArrayList<RectF> selected=new ArrayList<>(),candidates=new ArrayList<>();
    private float sx,sy; private RectF drawing;
    public Runnable onSelectionChanged;
    public RegionView(Context c){super(c);setContentDescription("图片预览：手指拖动框选水印，点击黄色候选框选择或取消");}
    public void setBitmap(Bitmap bitmap){image=bitmap;clear();invalidate();}
    public Bitmap bitmap(){return image;}
    public ArrayList<RectF> selected(){return new ArrayList<>(selected);}
    public void clear(){selected.clear();candidates.clear();drawing=null;invalidate();if(onSelectionChanged!=null)onSelectionChanged.run();}
    public void candidates(List<RectF> values){selected.clear();candidates.clear();candidates.addAll(values);invalidate();if(onSelectionChanged!=null)onSelectionChanged.run();}
    private RectF display(RectF r){return new RectF(bounds.left+r.left*bounds.width(),bounds.top+r.top*bounds.height(),bounds.left+r.right*bounds.width(),bounds.top+r.bottom*bounds.height());}
    @Override protected void onDraw(Canvas c){
        super.onDraw(c);c.drawColor(Color.rgb(237,241,248));if(image==null)return;
        float scale=Math.min((float)getWidth()/image.getWidth(),(float)getHeight()/image.getHeight());
        float w=image.getWidth()*scale,h=image.getHeight()*scale;bounds.set((getWidth()-w)/2,(getHeight()-h)/2,(getWidth()+w)/2,(getHeight()+h)/2);
        paint.setStyle(Paint.Style.FILL);c.drawBitmap(image,null,bounds,paint);
        paint.setStrokeWidth(3*getResources().getDisplayMetrics().density);paint.setStyle(Paint.Style.STROKE);
        paint.setColor(0xffffaa00);for(RectF r:candidates)c.drawRect(display(r),paint);
        paint.setColor(0xff2563eb);for(RectF r:selected)c.drawRect(display(r),paint);
        if(drawing!=null)c.drawRect(display(drawing),paint);paint.setStyle(Paint.Style.FILL);
    }
    @Override public boolean onTouchEvent(MotionEvent e){
        if(!isEnabled()||image==null||bounds.width()==0)return false;
        float x=Math.max(0,Math.min(1,(e.getX()-bounds.left)/bounds.width())),y=Math.max(0,Math.min(1,(e.getY()-bounds.top)/bounds.height()));
        switch(e.getActionMasked()){
            case MotionEvent.ACTION_DOWN:
                if(!bounds.contains(e.getX(),e.getY()))return false;
                getParent().requestDisallowInterceptTouchEvent(true);sx=x;sy=y;drawing=new RectF(x,y,x,y);return true;
            case MotionEvent.ACTION_MOVE: drawing=new RectF(Math.min(sx,x),Math.min(sy,y),Math.max(sx,x),Math.max(sy,y));invalidate();return true;
            case MotionEvent.ACTION_UP:
                if(drawing!=null&&drawing.width()>.01&&drawing.height()>.01){if(selected.size()<5)selected.add(new RectF(drawing));}
                else {boolean handled=false;for(int i=selected.size()-1;i>=0;i--)if(selected.get(i).contains(x,y)){selected.remove(i);handled=true;break;}
                    if(!handled)for(RectF r:candidates)if(r.contains(x,y)){if(selected.size()<5)selected.add(new RectF(r));break;}}
                drawing=null;getParent().requestDisallowInterceptTouchEvent(false);invalidate();if(onSelectionChanged!=null)onSelectionChanged.run();performClick();return true;
            case MotionEvent.ACTION_CANCEL:drawing=null;getParent().requestDisallowInterceptTouchEvent(false);invalidate();return true;
        }return true;
    }
    @Override public boolean performClick(){super.performClick();return true;}
}
