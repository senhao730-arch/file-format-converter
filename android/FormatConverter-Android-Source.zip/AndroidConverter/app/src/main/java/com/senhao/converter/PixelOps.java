package com.senhao.converter;

/** Pure pixel operations, also exercised on the host JVM. */
public final class PixelOps {
    private PixelOps() {}
    static int clamp(int n) { return Math.max(0,Math.min(255,n)); }
    public static int[] detail(int[] original,int w,int h,float sharpen,float denoise) {
        if (original.length!=w*h || w<1 || h<1) throw new IllegalArgumentException("无效图片尺寸");
        int[] out=original.clone();
        for(int y=1;y<h-1;y++) for(int x=1;x<w-1;x++) {
            int i=y*w+x,a=original[i]>>>24,v=a<<24;
            for(int shift=0;shift<=16;shift+=8) {
                int c=(original[i]>>>shift)&255,sum=0;
                for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++)sum+=(original[(y+dy)*w+x+dx]>>>shift)&255;
                float mean=sum/9f,smooth=c*(1-denoise)+mean*denoise;
                v|=clamp(Math.round(smooth+sharpen*(c-mean)))<<shift;
            }
            out[i]=v;
        }
        return out;
    }
    public static void repair(int[] pixels,int w,int h,int left,int top,int right,int bottom) {
        left=Math.max(1,left);top=Math.max(1,top);right=Math.min(w-1,right);bottom=Math.min(h-1,bottom);
        if(right<=left||bottom<=top)throw new IllegalArgumentException("区域过大或太靠近边缘，请向内缩小框选");
        int[] source=pixels.clone();
        for(int y=top;y<bottom;y++)for(int x=left;x<right;x++) {
            float tx=(x-left+1f)/(right-left+1f),ty=(y-top+1f)/(bottom-top+1f);
            int lc=source[y*w+left-1],rc=source[y*w+right],tc=source[(top-1)*w+x],bc=source[bottom*w+x];
            int value=source[y*w+x]&0xff000000;
            for(int s=0;s<=16;s+=8) {
                float horizontal=((lc>>>s)&255)*(1-tx)+((rc>>>s)&255)*tx;
                float vertical=((tc>>>s)&255)*(1-ty)+((bc>>>s)&255)*ty;
                value|=clamp(Math.round((horizontal+vertical)/2))<<s;
            }
            pixels[y*w+x]=value;
        }
    }
    public static int[] fit(int width,int height,int requestedWidth,int requestedHeight) {
        if(width<1||height<1||requestedWidth<0||requestedHeight<0)throw new IllegalArgumentException("无效分辨率");
        if(requestedWidth==0&&requestedHeight==0)return new int[]{width,height};
        double scale=requestedWidth==0?(double)requestedHeight/height:requestedHeight==0?(double)requestedWidth/width:Math.min((double)requestedWidth/width,(double)requestedHeight/height);
        int w=Math.max(1,(int)Math.round(width*scale)),h=Math.max(1,(int)Math.round(height*scale));
        if(w>8192||h>8192||(long)w*h>24_000_000)throw new IllegalArgumentException("分辨率过大，请控制在 2400 万像素、单边 8192 以内");
        return new int[]{w,h};
    }
}
