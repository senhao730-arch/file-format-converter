# 第三方组件

本 APK 使用 Android 平台 API 与以下 Apache-2.0 开源运行库：

- AndroidX Core 1.16.0、ExifInterface 1.4.1、相应的 AndroidX Annotation / Collection / Lifecycle / Startup 等传递依赖；版权为 The Android Open Source Project / AndroidX contributors。
- AndroidX Media3 Transformer / Effect 1.8.0 及其 Common / Container / Decoder / ExoPlayer / Extractor / Muxer / DataSource 等传递依赖；版权为 The Android Open Source Project / Google LLC。
- Google Guava Android 及 FailureAccess、相关注解库；版权为 Google Inc. / Google LLC 及贡献者。
- Kotlin 标准库和 JetBrains 注解（由 AndroidX 传递引入）；版权为 JetBrains s.r.o. 及贡献者。
- Kotlinx Coroutines 1.6.4 与 JSpecify 1.0.0；Apache-2.0。

正式 APK 的完整依赖版本清单见 DEPENDENCIES.txt。

APK 与源码附 Apache-2.0 全文：app/src/main/assets/licenses/Apache-2.0.txt。未对第三方库源码作修改。Android 系统解码器/编码器属于手机系统，不另行打包 FFmpeg、Office、LibreOffice 或 Windows/Python 运行时。

JUnit 4.13.2（EPL-1.0）、AndroidX Test（Apache-2.0）仅用于开发测试，不进入正式 APK。Gradle、AGP、JDK 与 Android SDK 属于构建环境，不进入源码 ZIP 或 APK。

项目的 Gradle 依赖版本在 app/build.gradle 中固定，可执行 dependencies 查阅完整传递依赖。源码包不包含签名私钥、SDK、构建缓存或本机路径配置。
